import pandas as pd
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn import tree

import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

pd.options.display.max_columns = 8

# ---------- predefined functions ------------------
def label_freq_count(input_list):
    return {k: sum([1 for l in input_list if l == k]) for k, v in dict(zip(set(input_list), [0] * len(input_list))).items()}


def map_labels(input_list, input_map):
    return [input_map[l] for l in input_list]


def get_index_of_label(input_list, select_label):
    return [i for i, l in enumerate(input_list) if l == select_label]


def get_obs_subset(input_list, index_locs):
    return [input_list[i] for i in index_locs]


def flatten_list(input_list):
    output_list = list()
    for l in input_list:
        output_list.extend(l)
    return output_list


def clean_word_list(input_list, drop_words_list):
    input_list = [word for word in input_list if word.lower() not in drop_words_list]  # drop irrelevant words
    input_list = [word for word in input_list if word.isalpha()]  # drop items that are not words, e.g. punctuation
    input_list = [word.lower() for word in input_list]  # convert all to lower case to ignore capilization
    return input_list


def get_words(obs_list, drop_words_list):
    split = [nltk.word_tokenize(t) for t in obs_list]
    cleaned_split = [clean_word_list(t, drop_words_list) for t in split]
    return split, cleaned_split


def examine_frequency_distributions(input_text_split, drop_words_list, top_number, input_class):
    # extract frequency distribution for our data
    tweets_word_lists, tweets_word_lists_cleaned = get_words(input_text_split,
                                                             drop_words_list)  # break into lists of words

    top_n_all_words = nltk.FreqDist(flatten_list(tweets_word_lists)).most_common(top_number)
    top_n_clean_words = nltk.FreqDist(flatten_list(tweets_word_lists_cleaned)).most_common(top_number)
    print("Top %d most common words %s tweets:\n%s" % (top_number, input_class, top_n_all_words))  # all tweets
    print(
        "Top %d most common cleaned words %s tweets:\n%s" % (top_number, input_class, top_n_clean_words))  # all tweets

    plt.figure()
    nltk.FreqDist(flatten_list(tweets_word_lists)).plot(top_number, title=input_class + ", all words")

    plt.figure()
    nltk.FreqDist(flatten_list(tweets_word_lists_cleaned)).plot(top_number, title=input_class + ", cleaned words only")


def get_select_n_words(obs_list, drop_words_list, top_n_words):
    _, obs_words_list = get_words(obs_list, drop_words_list)
    return [w[0] for w in nltk.FreqDist(flatten_list(obs_words_list)).most_common(top_n_words)]


def create_informative_word_list(input_text, input_labels, drop_words_list, class_list, top_n_words):
    return set(flatten_list([get_select_n_words(get_obs_subset(input_text, get_index_of_label(input_labels, c)), drop_words_list, top_n_words) for c in class_list]))


def create_bag_of_words(obs, select_words):
    return {k: sum([1 for w in obs if w == k]) for k in select_words}


def import_data(text_filename, label_filename, label_map):
    with open(text_filename, 'r') as f:
        orig_text = f.read()
    split_text = orig_text.split("\n")  # break into separate tweets by line

    with open(label_filename, 'r') as f:
        orig_labels = f.read()
    orig_labels = orig_labels.split("\n")
    mapped_labels = map_labels(orig_labels, label_map)  # map numbers to emotion based on data dictionary
    print('Class (mapped) frequency:\n%s' % label_freq_count(mapped_labels))
    return split_text, mapped_labels


def format_data_as_dataframe(text_list, label_list, drop_words_list):
    _, text_word_lists = get_words(text_list, drop_words_list)
    df = pd.DataFrame({'orig_data': text_list, 'relevant_word_list': text_word_lists, 'class': label_list})
    return df


def add_bag_of_words_to_dataframe(df, word_list_column_name, select_words):
    return pd.concat([df, df[word_list_column_name].apply(lambda x: create_bag_of_words(x, select_words)).apply(pd.Series)], axis=1)


# --------------------------------------------

# ================================ IMPORT TRAINING DATA SET ===========================================================
training_text_filename = 'emotion_train_text.txt'
training_label_filename = 'emotion_train_labels.txt'
emotion_label_map = {'0': 'anger', '1': 'joy', '2': 'optimism', '3': 'sadness'}
train_text, train_labels = import_data(text_filename=training_text_filename, label_filename=training_label_filename, label_map=emotion_label_map)
# --------------------------------------
##### how long is the list "train_text"?
###### print the first item in the list "train_text": what is it?
##### how long is the list "train_labels"?
##### print the first item in the list "train_labels": what is it?
# --------------------------------------

# create list of words to ignore
drop_words = nltk.corpus.stopwords.words('english')  # common english words like "the", "and", part of nltk library
drop_words.extend([word.lower() for word in nltk.corpus.names.words()])  # common english names, part of nltk library
# --------------------------------------
##### what are the first five words in the list "drop_words"?
##### how many words in the English language do we consider uninformative (for this analysis)?
# --------------------------------------
# =====================================================================================================================

# ================================ EXAMINE FREQUENCY DISTRIBUTIONS ====================================================
top_n_words = 10
examine_frequency_distributions(train_text, drop_words, top_n_words, "all tweets")   # all tweets
# --------------------------------------
#### what are the top 10 "words" if we don't do any cleaning?
#### what are the top 10 "words" if we clean the text?
# --------------------------------------

# --- examine tweets by emotional class
select_class = "sadness"    # options are sadness, anger, joy, optimism
select_class_texts = get_obs_subset(train_text, get_index_of_label(train_labels, select_class))
examine_frequency_distributions(select_class_texts, drop_words, top_n_words, select_class)
# --------------------------------------
##### are there overlapping words that are common in any of the emotions? which are the most distinct?
# --------------------------------------

# ---  create list of most informative words
top_n_informative_words_by_class = 100
select_informative_words = create_informative_word_list(train_text, train_labels, drop_words, class_list=['anger', 'sadness', 'joy', 'optimism'], top_n_words=top_n_informative_words_by_class)
# --------------------------------------
##### how many informative words are in the list? how many words must appear in at least more than one of the class lists?
# --------------------------------------
# =====================================================================================================================

# ================================ TRAIN DECISION TREE TO CLASSIFY TWEETS =============================================
# ---- change data structure from lists -> dataframe
train_df = format_data_as_dataframe(train_text, train_labels, drop_words)
# --------------------------------------
###### how many rows and columns are there?
###### print the first five rows of the data frame
# --------------------------------------

# --- create bag of words from word lists and add as dataframe columns
train_df = add_bag_of_words_to_dataframe(train_df, 'relevant_word_list', select_informative_words)
# --------------------------------------
###### how many rows and columns are there?
###### does the change in columns make sense?
# --------------------------------------

# --- get X and y data
select_target_variable = 'class'
feature_names = select_informative_words    ##### how else could we get this?
X_train = train_df[feature_names]
y_train = train_df[select_target_variable]

# --- fit decision tree
decision_tree = DecisionTreeClassifier(max_depth=3)
decision_tree.fit(X=X_train, y=y_train)

# --- visualize decision tree
fig, _ = plt.subplots(nrows=1, ncols=1, figsize=(5.5, 3))    #
tree.plot_tree(decision_tree, filled=True, feature_names=decision_tree.feature_names_in_, class_names=[str(i) for i in decision_tree.classes_], fontsize=10)
plt.show()
# --------------------------------------
########## what are the top 3 most informative words in our data set?
########## with a tree three levels deep, are all of our classes represented? how much "flexibility" in the model do you have to allow to get all classes?
# --------------------------------------

# --------------------------------------
####### how do we classify as [positive, negative] instead of ['anger', 'sadness', 'joy', 'optimism']?
##### what is the minimum max_depth we need to get all classes? Why do we need a less flexible model?
# --------------------------------------
# =====================================================================================================================

# ============================ IMPORT TEST DATA SET ==================================================================
test_text_filename = 'emotion_test_text.txt'
test_label_filename = 'emotion_test_labels.txt'
test_text, test_labels = import_data(text_filename=test_text_filename, label_filename=test_label_filename, label_map={'0': 'anger', '1': 'joy', '2': 'optimism', '3': 'sadness'})
test_df = format_data_as_dataframe(test_text, test_labels, drop_words)  # make into dataframe
test_df = add_bag_of_words_to_dataframe(test_df, 'relevant_word_list', select_informative_words)   # expand columns to bag of words
test_df['sentiment'] = test_df['class'].map({'anger': 'negative', 'sadness': 'negative', 'joy': 'positive', 'optimism': 'positive'})    # map class to sentiment
#-----------------------------------
####### what shape is our dataframe?
####### how many observations are in our test set?
####### what is the relative proportion of training to test data?
#----------------------------------
# =====================================================================================================================

# ============================ MAKE PREDICTIONS USING BOTH DECISION TREE AND PYTHON NLTK LIBRARY ======================
# -------- predict *training* set "sentiment" using decision tree fit to training set-------------
y_decision_tree_predictions_training_data = decision_tree.predict(X=X_train)

# -------- predict *test* set "sentiment" using decision tree fit to training set-----------------
X_test = test_df[select_informative_words]
y_test = test_df[select_target_variable]
y_decision_tree_predictions_test_data = decision_tree.predict(X=X_test)

#-----------------------------------
####### what shape is our training prediction data (X)? test prediction data (X)? should these have the same number of rows? columns?
####### how long is our training predictions list?
####### how long is our test predictions list?
#-----------------------------------

# -------- predict *test* set "sentiment" using nltk SentimentIntensityAnalyzer ------------------
# the SentimentIntensityAnalyzer class (data structure) has a trained model stored "inside" of it,
# so we do not need to train ourselves like we do with a decision tree
sia_model = SentimentIntensityAnalyzer()
sia_scores = list()
for obs in test_df['orig_data']:
    sia_scores.append(sia_model.polarity_scores(obs))
#-----------------------------------
####### how long is the list sia_scores?
####### print the compound score for the first observation in our data set
#-----------------------------------

# map sia_scores -> [positive, negative].
# Note: compound score of <0 means negative, >0 means positive, 0 = neutral from the SentimentIntensityAnalyzer docs
y_sia_predictions_test_data = ["positive" if (s['compound'] >= 0) else "negative" for s in sia_scores]
#-----------------------------------
####### how long is our test predictions list?
#-----------------------------------
# =====================================================================================================================

# ============================ COMPARE MODELS DECISION TREE AND NLTK SIA PREDICTIONS ==================================
# -------- summarize *training* predictions using decision tree fit to training set-------------
print("\n\n---------- The training data predictions using decision tree model ----------")
print("Confusion matrix:\n%s" % confusion_matrix(y_true=y_train, y_pred=y_decision_tree_predictions_training_data))  # confusion matrix
print(classification_report(y_true=y_train, y_pred=y_decision_tree_predictions_training_data))  # classification report

# -------- summarize *test* set predictions using decision tree fit to training set-----------------
print("\n\n---------- The test data predictions using decision tree model ----------")
# print("Confusion matrix:\n%s" % confusion_matrix(y_true=, y_pred=))  # confusion matrix
# print(classification_report(y_true=, y_pred=))   # classification report

# -------- summarize *test* set predictions using nltk SentimentIntensityAnalyzer ------------------
print("\n\n---------- The test data predictions using nltk SentimentIntensityAnalyzer model ----------")
# print("Confusion matrix:\n%s" % confusion_matrix(y_true=, y_pred=))  # confusion matrix
# print(classification_report(y_true=, y_pred=)) # classification report
# =====================================================================================================================
